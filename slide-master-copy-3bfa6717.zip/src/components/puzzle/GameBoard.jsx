
import React from "react";
import { motion } from "framer-motion";

import Tile from "./Tile";

export default function GameBoard({ 
  tiles, 
  emptyIndex, 
  onTileClick, 
  getValidMoves,
  isShuffling,
  difficulty 
}) {
  const validMoves = getValidMoves(emptyIndex);

  // Don't render if tiles aren't initialized
  if (!tiles || tiles.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-slate-500">Loading puzzle...</div>
      </div>
    );
  }

  return (
    <div className="relative">
      <motion.div 
        className={`grid gap-2 p-4 bg-gradient-to-br from-slate-100 to-slate-200 rounded-2xl shadow-inner`}
        style={{ 
          gridTemplateColumns: `repeat(${difficulty.cols}, 1fr)`,
          gridTemplateRows: `repeat(${difficulty.rows}, 1fr)`
        }}
        animate={isShuffling ? { rotate: [0, 2, -2, 0] } : {}}
        transition={{ duration: 0.6, repeat: isShuffling ? Infinity : 0 }}
      >
        {tiles.map((tile, index) => (
          <Tile
            key={`${index}-${tile}`}
            number={tile}
            index={index}
            isEmpty={tile === null}
            isClickable={validMoves.includes(index)}
            onClick={() => onTileClick(index)}
            isShuffling={isShuffling}
            size={difficulty.cols === 3 ? 'large' : 'normal'}
          />
        ))}
      </motion.div>
      
      {isShuffling && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/70 backdrop-blur-sm rounded-2xl">
          <div className="text-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-8 h-8 border-3 border-blue-500 border-t-transparent rounded-full mx-auto mb-2"
            />
            <p className="text-slate-700 font-medium">Shuffling...</p>
          </div>
        </div>
      )}
    </div>
  );
}
