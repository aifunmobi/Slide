import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Sparkles, Target, Timer } from "lucide-react";

export default function WinModal({ isOpen, moves, time, onPlayAgain, difficulty }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 50 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
          >
            <Card className="w-full max-w-sm mx-auto shadow-2xl border-0 bg-gradient-to-br from-white to-blue-50">
              <CardHeader className="text-center pb-4">
                <motion.div
                  animate={{ 
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0] 
                  }}
                  transition={{ 
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg"
                >
                  <Trophy className="w-10 h-10 text-white" />
                </motion.div>
                
                <CardTitle className="text-2xl font-bold text-slate-800">
                  Congratulations! 🎉
                </CardTitle>
                <p className="text-slate-600">You solved the {difficulty} puzzle!</p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-white/60 rounded-lg">
                    <div className="flex items-center justify-center gap-2 text-slate-600 mb-1">
                      <Target className="w-4 h-4" />
                      <span className="text-sm">Moves</span>
                    </div>
                    <div className="text-xl font-bold text-slate-800">{moves}</div>
                  </div>
                  
                  <div className="text-center p-3 bg-white/60 rounded-lg">
                    <div className="flex items-center justify-center gap-2 text-slate-600 mb-1">
                      <Timer className="w-4 h-4" />
                      <span className="text-sm">Time</span>
                    </div>
                    <div className="text-xl font-bold text-slate-800 font-mono">{time}</div>
                  </div>
                </div>
                
                <Button
                  onClick={onPlayAgain}
                  className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white border-0"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Play Again
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}