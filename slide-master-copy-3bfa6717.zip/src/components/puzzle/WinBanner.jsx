import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function WinBanner({ isOpen }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.5 } }}
          className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 pointer-events-none"
        >
          <motion.div
            initial={{ scale: 0.5, opacity: 0, y: -100 }}
            animate={{ 
                scale: 1, 
                opacity: 1, 
                y: 0, 
                transition: { type: 'spring', damping: 15, stiffness: 150 } 
            }}
            exit={{ scale: 1.5, opacity: 0, transition: { duration: 0.5 } }}
            className="text-center"
          >
            <h1 
              className="text-6xl md:text-8xl font-black text-white uppercase tracking-wider" 
              style={{ WebkitTextStroke: '3px #1e40af', textShadow: '0px 5px 15px rgba(0,0,0,0.3)' }}
            >
              YOU WON!
            </h1>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}