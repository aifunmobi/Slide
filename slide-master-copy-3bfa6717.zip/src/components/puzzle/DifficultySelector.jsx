import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Zap, Target } from "lucide-react";

const DIFFICULTIES = {
  easy: { 
    name: "Easy", 
    tiles: 11, 
    description: "3×4 grid with 11 tiles",
    icon: Zap,
    color: "from-green-400 to-emerald-600"
  },
  classic: { 
    name: "Classic", 
    tiles: 15, 
    description: "4×4 grid with 15 tiles",
    icon: Target,
    color: "from-blue-400 to-indigo-600"
  }
};

export default function DifficultySelector({ 
  isOpen, 
  currentDifficulty, 
  onSelect, 
  onClose 
}) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 50 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
          >
            <Card className="w-full max-w-sm mx-auto shadow-2xl border-0 bg-white">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <CardTitle className="text-xl font-bold text-slate-800">
                  Choose Difficulty
                </CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              
              <CardContent className="space-y-3">
                {Object.entries(DIFFICULTIES).map(([key, diff]) => {
                  const IconComponent = diff.icon;
                  const isSelected = currentDifficulty === key;
                  
                  return (
                    <motion.button
                      key={key}
                      onClick={() => onSelect(key)}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all duration-200 ${
                        isSelected 
                          ? 'border-blue-400 bg-blue-50' 
                          : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br ${diff.color} shadow-lg`}>
                          <IconComponent className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-slate-800">{diff.name}</h3>
                            {isSelected && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            )}
                          </div>
                          <p className="text-sm text-slate-600">{diff.description}</p>
                        </div>
                      </div>
                    </motion.button>
                  );
                })}
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}