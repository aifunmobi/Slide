import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Timer, Target, RotateCcw, Shuffle } from "lucide-react";
import { motion } from "framer-motion";

export default function GameControls({ 
  moves, 
  time, 
  onReset, 
  onShuffle,
  isShuffling 
}) {
  return (
    <Card className="mb-6 shadow-lg border-0 bg-white/70 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-6">
            <div className="text-center">
              <div className="flex items-center gap-2 text-slate-600 mb-1">
                <Target className="w-4 h-4" />
                <span className="text-sm font-medium">Moves</span>
              </div>
              <motion.div 
                key={moves}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="text-2xl font-bold text-slate-800"
              >
                {moves}
              </motion.div>
            </div>
            
            <div className="text-center">
              <div className="flex items-center gap-2 text-slate-600 mb-1">
                <Timer className="w-4 h-4" />
                <span className="text-sm font-medium">Time</span>
              </div>
              <div className="text-2xl font-bold text-slate-800 font-mono">
                {time}
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={onShuffle}
            disabled={isShuffling}
            className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white border-0"
          >
            <Shuffle className="w-4 h-4 mr-2" />
            {isShuffling ? 'Shuffling...' : 'Shuffle'}
          </Button>
          
          <Button
            onClick={onReset}
            variant="outline"
            disabled={isShuffling}
            className="flex-1 border-slate-300 hover:bg-slate-50"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}