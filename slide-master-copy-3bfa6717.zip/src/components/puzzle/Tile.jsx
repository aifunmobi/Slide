import React from "react";
import { motion } from "framer-motion";

export default function Tile({ 
  number, 
  index, 
  isEmpty, 
  isClickable, 
  onClick,
  isShuffling,
  size = 'normal'
}) {
  if (isEmpty) {
    return <div className="aspect-square" />;
  }

  const sizeClasses = size === 'large' 
    ? 'text-xl' 
    : 'text-lg';

  return (
    <motion.button
      onClick={onClick}
      disabled={!isClickable || isShuffling}
      className={`
        aspect-square rounded-xl font-bold ${sizeClasses} shadow-lg border-2 transition-all duration-200
        ${isClickable && !isShuffling
          ? 'bg-gradient-to-br from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 text-white border-blue-300 cursor-pointer hover:shadow-xl hover:scale-105 active:scale-95' 
          : 'bg-gradient-to-br from-slate-300 to-slate-400 text-slate-600 border-slate-200 cursor-default'
        }
      `}
      whileTap={{ scale: isClickable ? 0.95 : 1 }}
      whileHover={{ scale: isClickable ? 1.05 : 1 }}
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        rotate: isShuffling ? [0, 5, -5, 0] : 0
      }}
      transition={{ 
        duration: 0.3,
        rotate: { duration: 0.6, repeat: isShuffling ? Infinity : 0 }
      }}
    >
      <span className="drop-shadow-sm">
        {number}
      </span>
    </motion.button>
  );
}