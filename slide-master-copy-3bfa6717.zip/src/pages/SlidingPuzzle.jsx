
import React, { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, RotateCcw, Shuffle, Timer, Target, Settings } from "lucide-react";

import GameBoard from "../components/puzzle/GameBoard";
import GameControls from "../components/puzzle/GameControls";
import WinModal from "../components/puzzle/WinModal";
import DifficultySelector from "../components/puzzle/DifficultySelector";
import WinBanner from "../components/puzzle/WinBanner";

const DIFFICULTIES = {
  easy: { name: "Easy", tiles: 11, rows: 3, cols: 4, totalSpaces: 12 },
  classic: { name: "Classic", tiles: 15, rows: 4, cols: 4, totalSpaces: 16 }
};

const playSound = (src) => {
  if (!src) return;
  try {
    const audio = new Audio(src);
    audio.play().catch(e => console.warn("Could not play audio:", e));
  } catch (error) {
    console.warn("Could not create audio element:", error);
  }
};

const SOUNDS = {
  move: 'https://cdn.pixabay.com/audio/2022/03/15/audio_2491c9535b.mp3',
  shuffle: 'https://cdn.pixabay.com/audio/2022/11/22/audio_2c0b433a59.mp3',
  reset: 'https://cdn.pixabay.com/audio/2022/03/10/audio_5514f24d3a.mp3',
  win: 'https://cdn.pixabay.com/audio/2022/01/20/audio_03789c4883.mp3'
};

export default function SlidingPuzzle() {
  const [difficulty, setDifficulty] = useState('classic');
  const [tiles, setTiles] = useState([]);
  const [emptyIndex, setEmptyIndex] = useState(15);
  const [moves, setMoves] = useState(0);
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isWon, setIsWon] = useState(false);
  const [isShuffling, setIsShuffling] = useState(false);
  const [showDifficultySelector, setShowDifficultySelector] = useState(false);
  const [showWinBanner, setShowWinBanner] = useState(false);

  const currentDiff = DIFFICULTIES[difficulty];

  // Initialize solved puzzle
  const initializePuzzle = useCallback(() => {
    if (tiles.length > 0) { // Don't play on initial load, only on subsequent resets
      playSound(SOUNDS.reset);
    }
    
    // Create array with correct number of positions
    const newTiles = new Array(currentDiff.totalSpaces);
    
    // Fill with numbers 1 to tiles count
    for (let i = 0; i < currentDiff.tiles; i++) {
      newTiles[i] = i + 1;
    }
    
    // Last position is empty (null)
    newTiles[currentDiff.tiles] = null;
    
    setTiles(newTiles);
    setEmptyIndex(currentDiff.tiles);
    setMoves(0);
    setTime(0);
    setIsRunning(false);
    setIsWon(false);
    setShowWinBanner(false);
  }, [currentDiff, tiles.length]);

  // Check if puzzle is solved
  const checkWin = useCallback((currentTiles) => {
    // Check if numbers 1 to tiles are in correct positions
    for (let i = 0; i < currentDiff.tiles; i++) {
      if (currentTiles[i] !== i + 1) return false;
    }
    // Check if empty space is in last position
    return currentTiles[currentDiff.tiles] === null;
  }, [currentDiff.tiles]);

  // Get valid moves for current empty position
  const getValidMoves = useCallback((emptyPos) => {
    const moves = [];
    const row = Math.floor(emptyPos / currentDiff.cols);
    const col = emptyPos % currentDiff.cols;

    if (row > 0) moves.push(emptyPos - currentDiff.cols); // up
    if (row < currentDiff.rows - 1) moves.push(emptyPos + currentDiff.cols); // down  
    if (col > 0) moves.push(emptyPos - 1); // left
    if (col < currentDiff.cols - 1) moves.push(emptyPos + 1); // right

    return moves;
  }, [currentDiff]);

  // Move tile if valid
  const moveTile = useCallback((clickedIndex) => {
    if (isWon || isShuffling || tiles.length === 0) return;

    const validMoves = getValidMoves(emptyIndex);
    
    if (validMoves.includes(clickedIndex)) {
      const newTiles = [...tiles];
      newTiles[emptyIndex] = newTiles[clickedIndex];
      newTiles[clickedIndex] = null;
      
      setTiles(newTiles);
      setEmptyIndex(clickedIndex);
      setMoves(prev => prev + 1);
      playSound(SOUNDS.move);
      
      if (!isRunning) setIsRunning(true);

      // Check win condition
      if (checkWin(newTiles)) {
        setIsWon(true);
        setIsRunning(false);
        playSound(SOUNDS.win);
        setShowWinBanner(true);
        setTimeout(() => {
          setShowWinBanner(false);
        }, 5000);
      }
    }
  }, [tiles, emptyIndex, isWon, isShuffling, isRunning, getValidMoves, checkWin]);

  // Shuffle puzzle
  const shufflePuzzle = useCallback(() => {
    if (tiles.length === 0) return;
    
    setIsShuffling(true);
    playSound(SOUNDS.shuffle);
    let currentTiles = [...tiles];
    let currentEmpty = emptyIndex;
    
    // Perform random valid moves to ensure solvable puzzle
    const shuffleMoves = difficulty === 'easy' ? 300 : 500;
    for (let i = 0; i < shuffleMoves; i++) {
      const validMoves = getValidMoves(currentEmpty);
      if (validMoves.length === 0) break;
      const randomMove = validMoves[Math.floor(Math.random() * validMoves.length)];
      
      currentTiles[currentEmpty] = currentTiles[randomMove];
      currentTiles[randomMove] = null;
      currentEmpty = randomMove;
    }
    
    setTimeout(() => {
      setTiles(currentTiles);
      setEmptyIndex(currentEmpty);
      setMoves(0);
      setTime(0);
      setIsRunning(false);
      setIsWon(false);
      setIsShuffling(false);
    }, 600);
  }, [tiles, emptyIndex, getValidMoves, difficulty]);

  // Handle difficulty change
  const handleDifficultyChange = useCallback((newDifficulty) => {
    setDifficulty(newDifficulty);
    setShowDifficultySelector(false);
  }, []);

  // Timer effect
  useEffect(() => {
    let interval;
    if (isRunning) {
      interval = setInterval(() => {
        setTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  // Initialize puzzle when difficulty changes
  useEffect(() => {
    initializePuzzle();
  }, [initializePuzzle]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-4 flex items-center justify-center">
      <div className="w-full max-w-md mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-800">Sliding Puzzle</h1>
              <div className="flex items-center justify-center gap-2">
                <p className="text-slate-500 text-sm">{currentDiff.name} - {currentDiff.tiles} tiles</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDifficultySelector(true)}
                  className="p-1 h-auto text-slate-500 hover:text-slate-700"
                >
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <GameControls 
          moves={moves}
          time={formatTime(time)}
          onReset={initializePuzzle}
          onShuffle={shufflePuzzle}
          isShuffling={isShuffling}
        />

        {/* Game Board */}
        <Card className="mb-6 shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
          <CardContent className="p-6">
            <GameBoard 
              tiles={tiles}
              emptyIndex={emptyIndex}
              onTileClick={moveTile}
              getValidMoves={getValidMoves}
              isShuffling={isShuffling}
              difficulty={currentDiff}
            />
          </CardContent>
        </Card>

        {/* Instructions */}
        <div className="text-center text-slate-600 text-sm space-y-1">
          <p>Tap tiles adjacent to the empty space to move them</p>
          <p>Arrange numbers 1-{currentDiff.tiles} in order to win!</p>
        </div>

        {/* Win Banner */}
        <WinBanner isOpen={showWinBanner} />

        {/* Win Modal */}
        <WinModal 
          isOpen={isWon && !showWinBanner}
          moves={moves}
          time={formatTime(time)}
          onPlayAgain={shufflePuzzle}
          difficulty={currentDiff.name}
        />

        {/* Difficulty Selector */}
        <DifficultySelector 
          isOpen={showDifficultySelector}
          currentDifficulty={difficulty}
          onSelect={handleDifficultyChange}
          onClose={() => setShowDifficultySelector(false)}
        />
      </div>
    </div>
  );
}
